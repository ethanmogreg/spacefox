﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectCollision : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }


    //If player destroys a meteor, they will get 5 points for it.

    void OnTriggerEnter2D(Collider2D other)
    {
        Destroy(gameObject);
        Score.scoreValue += 5;
    }
}
