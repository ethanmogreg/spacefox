﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthText : MonoBehaviour
{
    // Start is called before the first frame update
    public static int healthValue = 3;
    public static Text health;
    void Start()
    {
        health = GetComponent<Text>();
    }

    // Update is called once per frame

    //Will display health value.

    void Update()
    {
        health.text = "" + healthValue;
    }
}
