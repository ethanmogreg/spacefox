﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    public Text scoreDisplay;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //If player presses enter on the game over screen, they will go back to the game. 
        //Resets score and health to 0 and 3.

        if (Input.GetKeyDown("return"))
        {
            SceneManager.LoadScene("SampleScene");
            Score.score = 0;
            HealthText.healthValue = 3;
        }
        
    }
}
