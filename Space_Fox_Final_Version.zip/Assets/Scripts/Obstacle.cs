﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public float lifetime;

    // Start is called before the first frame update

    //Destroys Game object (asteroid) after lifetime value.

     
    void Start()
    {
        Destroy(gameObject, lifetime);
    }

    public int damage = 1;
    public float speed;

    // Update is called once per frame


    //Obstacle will travel left towards the player, can be faster depending on speed value.

    void Update()
    {
        transform.Translate(Vector2.left * speed * Time.deltaTime);
    }


    //Player's health gets subtracted by 1 if they make contact with an obstacle. 
    //Obstacle will be destroyed if they make contact with player. 

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            HealthText.healthValue -= 1;
            other.GetComponent<Player>().health -= damage;
            Debug.Log(other.GetComponent<Player>().health);
            Destroy(gameObject);
        }

    }
}
