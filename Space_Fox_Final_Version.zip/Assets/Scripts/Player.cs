﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    // Start is called before the first frame update

    private Vector2 targetPos;
    public float Yincrement;
    public float speed;
    public float maxHeight;
    public float minHeight;
    public int health = 3;
    private AudioSource playerAudio;
    public AudioClip explosionSound;
    // Update is called once per frame

    private void Start()
    {
        playerAudio = GetComponent<AudioSource>();
    }

    void Update()
    {
        //Player gets Game Over if their health reaches 0.

        if (health <= 0)
        {
            SceneManager.LoadScene("GameOverScreen");
        }

        transform.position = Vector2.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);

        //Player will not go past maximum height

        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) && transform.position.y < maxHeight)
        {
            float nextY = transform.position.y + Yincrement;
            float nextY2 = Mathf.Clamp(nextY, minHeight, maxHeight);
            targetPos = new Vector2(transform.position.x, nextY2);
        }

        //Player will not go past minimum height

        else if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S) && transform.position.y > minHeight)
        {
            float nextY = transform.position.y - Yincrement;
            float nextY2 = Mathf.Clamp(nextY, minHeight, maxHeight);
            targetPos = new Vector2(transform.position.x, nextY2);
        }




    }
    // if player collides with obstacle, explosion sound will play.
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Obstacle"))
        {
            playerAudio.PlayOneShot(explosionSound, 1.0f);
        }
    }
}
