﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{

    public static int score;
    public Text scoreDisplay;

    // Update is called once per frame

    //Will display score.

    private void Start()
    {
        scoreDisplay.text = score.ToString();
    }

    void Update()
    {
        scoreDisplay.text = "" + score;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Obstacle"))
        {
            score++;
            Debug.Log(score);
        }
    
    }
}
