﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPoint : MonoBehaviour
{
    public GameObject Obstacle;
    // Start is called before the first frame update


    //Instantiates obstacles that move towards the player.
    void Start()
    {
        Instantiate(Obstacle, transform.position, Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
